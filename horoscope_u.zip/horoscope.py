import csv
import os
import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup as soup

#global variable

horo_list = []
#init driver for mac
chromedriver = "/usr/local/bin/chromedriver"
os.environ["webdriver.chrome.driver"] = chromedriver
options = webdriver.ChromeOptions()
prefs = {"profile.managed_default_content_settings.images":2,'profile.managed_default_content_settings.javascript': 2,"profile.default_content_setting_values.notifications" : 2}
chrome_options.add_experimental_option("prefs",prefs)
chrome_options.add_argument("--disable-popup-blocking")
driver = webdriver.Chrome(executable_path=chromedriver, chrome_options=options)
driver.set_window_position(-10000,0)

###init driver for windows
##chrome_options = webdriver.ChromeOptions()
##prefs = {"profile.managed_default_content_settings.images":2,'profile.managed_default_content_settings.javascript': 2,"profile.default_content_setting_values.notifications" : 2}
##chrome_options.add_experimental_option("prefs",prefs)
##chrome_options.add_argument("--disable-popup-blocking")
##driver = webdriver.Chrome(chrome_options=chrome_options)
###driver.set_window_position(-10000,0)

##www.horoscope.com
print("------www.horoscope.com------")
horoscope = {}
horoscope['Url'] = 'www.horoscope.com'
#Aries
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=1')
    horoscope['Aries'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=2')
    horoscope['Taurus'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=3')
    horoscope['Gemini'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=4')
    horoscope['Cancer'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=5')
    horoscope['Leo'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=6')
    horoscope['Virgo'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=7')
    horoscope['Libra'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=8')
    horoscope['Scorpio'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=9')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=10')
    horoscope['Capricorn'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=11')
    horoscope['Aquarius'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://www.horoscope.com/us/horoscopes/general/horoscope-general-daily-today.aspx?sign=12')
    horoscope['Pisces'] = driver.find_element_by_xpath("/html/body/div/section[2]/div/div/div[1]/div[1]/p[1]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.elle.com
print("------www.elle.com------")
horoscope = {}
horoscope['Url'] = 'www.elle.com'
#Aries
try:
    driver.get('https://www.elle.com/horoscopes/daily/a60/aries-daily-horoscope/')
    horoscope['Aries'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://www.elle.com/horoscopes/daily/a98/taurus-daily-horoscope/')
    horoscope['Taurus'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://www.elle.com/horoscopes/daily/a99/gemini-daily-horoscope/')
    horoscope['Gemini'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://www.elle.com/horoscopes/daily/a100/cancer-daily-horoscope/')
    horoscope['Cancer'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://www.elle.com/horoscopes/daily/a101/leo-daily-horoscope/')
    horoscope['Leo'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://www.elle.com/horoscopes/daily/a102/virgo-daily-horoscope/')
    horoscope['Virgo'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://www.elle.com/horoscopes/daily/a103/libra-daily-horoscope/')
    horoscope['Libra'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://www.elle.com/horoscopes/daily/a104/scorpio-daily-horoscope/')
    horoscope['Scorpio'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://www.elle.com/horoscopes/daily/a105/sagittarius-daily-horoscope/')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://www.elle.com/horoscopes/daily/a106/capricorn-daily-horoscope/')
    horoscope['Capricorn'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://www.elle.com/horoscopes/daily/a107/aquarius-daily-horoscope/')
    horoscope['Aquarius'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://www.elle.com/horoscopes/daily/a108/pisces-daily-horoscope/')
    horoscope['Pisces'] = driver.find_element_by_xpath("/html/body/div[2]/div[4]/div[1]/div[3]/p[1]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.horoscopes.huffingtonpost.com
print("------www.horoscopes.huffingtonpost.com------")
horoscope = {}
horoscope['Url'] = 'www.horoscopes.huffingtonpost.com'
#Aries
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/aries/')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/taurus/')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/gemini/')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/cancer/')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/leo/')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/virgo/')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/libra/')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/scorpio/')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/sagittarius/')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/capricorn/')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/aquarius/')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://horoscopes.huffingtonpost.com/astrology/pisces/')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='horoSlide']/div[2]/div[2]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.msn.com
print("------www.msn.com------")
horoscope = {}
horoscope['Url'] = 'https://www.msn.com'

driver.get('https://www.msn.com/en-us/lifestyle/horoscope')

Aries = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[1]/a").get_attribute('href')
Taurus = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[2]/a").get_attribute('href')
Gemini = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[3]/a").get_attribute('href')
Cancer = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[4]/a").get_attribute('href')
Leo = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[5]/a").get_attribute('href')
Virgo = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[6]/a").get_attribute('href')
Libra = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[7]/a").get_attribute('href')
Scorpio = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[8]/a").get_attribute('href')
Sagittarius = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[9]/a").get_attribute('href')
Capricorn = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[10]/a").get_attribute('href')
Aquarius = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[11]/a").get_attribute('href')
Pisces = driver.find_element_by_xpath("//*[@id='main']/div[2]/div/div/div[1]/ul/li[12]/a").get_attribute('href')

#Aries
try:
    driver.get(Aries)
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get(Taurus)
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get(Gemini)
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get(Cancer)
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get(Leo)
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get(Virgo)
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get(Libra)
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get(Scorpio)
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get(Sagittarius)
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get(Capricorn)
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get(Aquarius)
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get(Pisces)
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='main']/article/section/section[1]/p[2]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.astrocenter.com
print("------www.astrocenter.com------")
horoscope = {}
horoscope['Url'] = 'www.astrocenter.com'
#Aries
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=0&Af=0')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=1&Af=0')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=2&Af=0')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=3&Af=0')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=4&Af=0')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=5&Af=0')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=6&Af=0')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=7&Af=0')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=8&Af=0')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=9&Af=0')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=10&Af=0')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('http://www.astrocenter.com/us/horoscope-daily.aspx?When=0&ZSign=11&Af=0')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='textline']").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.nypost.com
print("------www.nypost.com------")
horoscope = {}
horoscope['Url'] = 'www.nypost.com'
driver.get('https://nypost.com/horoscopes/')
#Aries
try:
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[3]/article[1]/div/p").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[3]/article[2]/div/p").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[4]/article[1]/div/p").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[4]/article[2]/div/p").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[5]/article[1]/div/p").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[5]/article[2]/div/p").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[6]/article[1]/div/p").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[6]/article[2]/div/p").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[7]/article[1]/div/p").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[7]/article[2]/div/p").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[2]/article[1]/div/p").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='primary']/div/div[2]/article[2]/div/p").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.express.co.uk
print("------www.express.co.uk------")
horoscope = {}
horoscope['Url'] = 'www.express.co.uk'
#Aries
try:
    driver.get('https://www.express.co.uk/horoscope/aries/daily-forecast/today')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://www.express.co.uk/horoscope/taurus/daily-forecast/today')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://www.express.co.uk/horoscope/gemini/daily-forecast/today')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://www.express.co.uk/horoscope/cancer/daily-forecast/today')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://www.express.co.uk/horoscope/leo/daily-forecast/today')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://www.express.co.uk/horoscope/virgo/daily-forecast/today')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://www.express.co.uk/horoscope/libra/daily-forecast/today')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://www.express.co.uk/horoscope/scorpio/daily-forecast/today')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://www.express.co.uk/horoscope/sagittarius/daily-forecast/today')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://www.express.co.uk/horoscope/capricorn/daily-forecast/today')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://www.express.co.uk/horoscope/aquarius/daily-forecast/today')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://www.express.co.uk/horoscope/pisces/daily-forecast/today')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='horoscopesShell']/article/div[2]/p").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.honey.nine.com.au
print("------www.honey.nine.com.au------")
horoscope = {}
horoscope['Url'] = 'www.honey.nine.com.au'
#Aries
try:
    driver.get('https://honey.nine.com.au/horoscope/aries')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://honey.nine.com.au/horoscope/taurus')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://honey.nine.com.au/horoscope/gemini')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://honey.nine.com.au/horoscope/cancer')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://honey.nine.com.au/horoscope/leo')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://honey.nine.com.au/horoscope/virgo')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://honey.nine.com.au/horoscope/libra')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://honey.nine.com.au/horoscope/scorpio')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://honey.nine.com.au/horoscope/sagittarius')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://honey.nine.com.au/horoscope/capricorn')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://honey.nine.com.au/horoscope/aquarius')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://honey.nine.com.au/horoscope/pisces')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='Index']/div[2]/div/div[2]/div[1]/div/main/section[2]/p[1]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.ganeshaspeaks.com
print("------www.ganeshaspeaks.com------")
horoscope = {}
horoscope['Url'] = 'www.ganeshaspeaks.com'
#Aries
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/aries/')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/taurus/')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/gemini/')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/cancer/')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/leo/')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/virgo/')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/libra/')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/scorpio/')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/sagittarius/')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/capricorn/')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/aquarius/')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://www.ganeshaspeaks.com/horoscopes/daily-horoscope/pisces/')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='daily']/div/div[1]/div[2]/p[1]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.cafeastrology.com
print("------www.cafeastrology.com------")
horoscope = {}
horoscope['Url'] = 'www.cafeastrology.com'
#Aries
try:
    driver.get('https://cafeastrology.com/ariesdailyhoroscope.html')
    horoscope['Aries'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://cafeastrology.com/taurusdailyhoroscope.html')
    horoscope['Taurus'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://cafeastrology.com/geminidailyhoroscope.html')
    horoscope['Gemini'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://cafeastrology.com/cancerdailyhoroscope.html')
    horoscope['Cancer'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://cafeastrology.com/leodailyhoroscope.html')
    horoscope['Leo'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://cafeastrology.com/virgodailyhoroscope.html')
    horoscope['Virgo'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://cafeastrology.com/libradailyhoroscope.html')
    horoscope['Libra'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://cafeastrology.com/scorpiodailyhoroscope.html')
    horoscope['Scorpio'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://cafeastrology.com/sagittariusdailyhoroscope.html')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://cafeastrology.com/capricorndailyhoroscope.html')
    horoscope['Capricorn'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://cafeastrology.com/aquariusdailyhoroscope.html')
    horoscope['Aquarius'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://cafeastrology.com/piscesdailyhoroscope.html')
    horoscope['Pisces'] = driver.find_element_by_xpath("/html/body/div[2]/div[1]/div/main/article/div/p[4]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.washingtonpost.com
print("------www.washingtonpost.com------")
horoscope = {}
horoscope['Url'] = 'www.washingtonpost.com'
#Aries
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/aries/')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/taurus/')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/gemini/')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/cancer/')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/leo/')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/virgo/')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/libra/')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/scorpio/')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/sagittarius/')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/capricorn/')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/aquarius/')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://www.washingtonpost.com/entertainment/horoscopes/pisces/')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='sign-summary']").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.star4cast.ca
print("------www.star4cast.ca------")
horoscope = {}
horoscope['Url'] = 'www.star4cast.ca'
#Aries
try:
    driver.get('http://star4cast.ca/starsign/?ss=aries')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('http://star4cast.ca/starsign/?ss=taurus')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('http://star4cast.ca/starsign/?ss=gemini')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('http://star4cast.ca/starsign/?ss=cancer')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('http://star4cast.ca/starsign/?ss=leo')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('http://star4cast.ca/starsign/?ss=virgo')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('http://star4cast.ca/starsign/?ss=libra')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('http://star4cast.ca/starsign/?ss=scorpio')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('http://star4cast.ca/starsign/?ss=sagittarius')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('http://star4cast.ca/starsign/?ss=capricorn')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('http://star4cast.ca/starsign/?ss=aquarius')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('http://star4cast.ca/starsign/?ss=pisces')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='post-148']/div/div/div[3]/div[5]/p").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.astrologyanswers.com
print("------www.astrologyanswers.com------")
horoscope = {}
horoscope['Url'] = 'www.astrologyanswers.com'
#Aries
try:
    driver.get('https://astrologyanswers.com/horoscopes/aries-daily-horoscope/')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://astrologyanswers.com/horoscopes/taurus-daily-horoscope/')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://astrologyanswers.com/horoscopes/gemini-daily-horoscope/')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://astrologyanswers.com/horoscopes/cancer-daily-horoscope/')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://astrologyanswers.com/horoscopes/leo-daily-horoscope/')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://astrologyanswers.com/horoscopes/virgo-daily-horoscope/')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://astrologyanswers.com/horoscopes/libra-daily-horoscope/')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://astrologyanswers.com/horoscopes/scorpio-daily-horoscope/')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://astrologyanswers.com/horoscopes/sagittarius-daily-horoscope/')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://astrologyanswers.com/horoscopes/capricorn-daily-horoscope/')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://astrologyanswers.com/horoscopes/aquarius-daily-horoscope/')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://astrologyanswers.com/horoscopes/pisces-daily-horoscope/')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='today']/div/p").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.indianexpress.com
print("------www.indianexpress.com------")
horoscope = {}
horoscope['Url'] = 'www.indianexpress.com'
driver.get('http://indianexpress.com/photos/lifestyle-gallery/horoscope-of-the-week-2592738/')
#Aries
try:
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='1']/div[2]/div[2]/p[1]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='2']/div[2]/div[2]/p[1]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='3']/div[2]/div[2]/p[1]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='4']/div[2]/div[2]/p[1]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='5']/div[2]/div[2]/p[1]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='6']/div[2]/div[2]/p[1]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='7']/div[2]/div[2]/p[1]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='8']/div[2]/div[2]/p[1]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='9']/div[2]/div[2]/p[1]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='10']/div[2]/div[2]/p[1]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='11']/div[2]/div[2]/p[1]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='12']/div[2]/div[2]/p[1]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.m.tarot.com
print("------www.m.tarot.com------")
horoscope = {}
horoscope['Url'] = 'www.m.tarot.com'
#Aries
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/aries')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[3]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/taurus')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[3]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/gemini')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[3]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/cancer')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[3]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/leo')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[2]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/virgo')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[2]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/libra')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[2]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/scorpio')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[2]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/sagittarius')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[2]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/capricorn')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[2]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/aquarius')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[2]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://m.tarot.com/daily-love-horoscope/pisces')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='tarot-main-content']/div[2]/div[1]/div/div[2]/div[2]/p[1]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.seattletimes.com
print("------www.seattletimes.com------")
horoscope = {}
horoscope['Url'] = 'www.seattletimes.com'

driver.get('https://www.seattletimes.com/horoscopes/')
#Aries
try:
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[1]/span").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[2]/span").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[3]/span").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[4]/span").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[5]/span").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[6]/span").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[7]/span").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[8]/span").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[9]/span").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[10]/span").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[11]/span").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='post-10334504']/div/div[1]/div[2]/p[12]/span").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)

##www.astrolis.com
print("------www.astrolis.com------")
horoscope = {}
horoscope['Url'] = 'www.astrolis.com'
#Aries
try:
    driver.get('https://www.astrolis.com/horoscopes/aries')
    horoscope['Aries'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://www.astrolis.com/horoscopes/taurus')
    horoscope['Taurus'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://www.astrolis.com/horoscopes/gemini')
    horoscope['Gemini'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('hhttps://www.astrolis.com/horoscopes/cancer')
    horoscope['Cancer'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://www.astrolis.com/horoscopes/leo')
    horoscope['Leo'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://www.astrolis.com/horoscopes/virgo')
    horoscope['Virgo'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://www.astrolis.com/horoscopes/libra')
    horoscope['Libra'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://www.astrolis.com/horoscopes/scorpio')
    horoscope['Scorpio'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://www.astrolis.com/horoscopes/sagittarius')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://www.astrolis.com/horoscopes/capricorn')
    horoscope['Capricorn'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://www.astrolis.com/horoscopes/aquarius')
    horoscope['Aquarius'] = driver.find_element_by_xpath("/html/body/div[2]/div[7]/span").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://www.astrolis.com/horoscopes/pisces')
    horoscope['Pisces'] = driver.find_element_by_xpath("//html/body/div[2]/div[7]/span").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.astrology.com
print("------www.astrology.com------")
horoscope = {}
horoscope['Url'] = 'www.astrology.com'
#Aries
try:
    driver.get('https://www.astrology.com/horoscope/daily/aries.html')
    horoscope['Aries'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://www.astrology.com/horoscope/daily/taurus.html')
    horoscope['Taurus'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://www.astrology.com/horoscope/daily/gemini.html')
    horoscope['Gemini'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://www.astrology.com/horoscope/daily/cancer.html')
    horoscope['Cancer'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://www.astrology.com/horoscope/daily/leo.html')
    horoscope['Leo'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://www.astrology.com/horoscope/daily/virgo.html')
    horoscope['Virgo'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://www.astrology.com/horoscope/daily/libra.html')
    horoscope['Libra'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://www.astrology.com/horoscope/daily/scorpio.html')
    horoscope['Scorpio'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://www.astrology.com/horoscope/daily/sagittarius.html')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://www.astrology.com/horoscope/daily/capricorn.html')
    horoscope['Capricorn'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://www.astrology.com/horoscope/daily/aquarius.html')
    horoscope['Aquarius'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://www.astrology.com/horoscope/daily/pisces.html')
    horoscope['Pisces'] = driver.find_element_by_xpath("/html/body/section[1]/div[3]/p[1]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.dailyom.com
print("------www.dailyom.com------")
horoscope = {}
horoscope['Url'] = 'www.dailyom.com'
#Aries
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=2')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Aries'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=11')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Taurus'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=5')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Gemini'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=3')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Cancer'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=6')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Leo'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=12')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Virgo'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=7')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Libra'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=10')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Scorpio'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=9')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Sagittarius'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=4')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Capricorn'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=1')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Aquarius'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://www.dailyom.com/cgi-bin/display/horoscopes.cgi?sign=8')
    temp_url = driver.find_element_by_xpath("//*[@id='top-40-first-row-title']/a").get_attribute('href')
    driver.get(temp_url)
    horoscope['Pisces'] = driver.find_element_by_xpath("/html/body/div[5]/span/div").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.thesun.co.uk
print("------www.thesun.co.uk------")
horoscope = {}
horoscope['Url'] = 'www.thesun.co.uk'
driver.get('https://www.thesun.co.uk/fabulous/horoscopes/')
temp_url = driver.find_element_by_xpath("//*[@id='main-content']/section/div[1]/div[1]/div/a").get_attribute('href')
driver.get(temp_url)
#Aries
try:
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[3]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[8]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[12]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[16]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[21]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[28]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[33]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[37]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[41]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[49]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[53]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='main-content']/section/div/div[1]/article/div[2]/div[1]/p[63]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)




##www.everydayhoroscopes.com
print("------www.everydayhoroscopes.com------")
horoscope = {}
horoscope['Url'] = 'www.everydayhoroscopes.com'
#Aries
try:
    driver.get('https://everydayhoroscopes.com/aries/horoscope/today/')
    horoscope['Aries'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://everydayhoroscopes.com/taurus/horoscope/today/')
    horoscope['Taurus'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://everydayhoroscopes.com/gemini/horoscope/today/')
    horoscope['Gemini'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://everydayhoroscopes.com/cancer/horoscope/today/')
    horoscope['Cancer'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://everydayhoroscopes.com/leo/horoscope/today/')
    horoscope['Leo'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://everydayhoroscopes.com/virgo/horoscope/today/')
    horoscope['Virgo'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://everydayhoroscopes.com/libra/horoscope/today/')
    horoscope['Libra'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://everydayhoroscopes.com/scorpio/horoscope/today/')
    horoscope['Scorpio'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://everydayhoroscopes.com/sagittarius/horoscope/today/')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://everydayhoroscopes.com/capricorn/horoscope/today/')
    horoscope['Capricorn'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://everydayhoroscopes.com/aquarius/horoscope/today/')
    horoscope['Aquarius'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://everydayhoroscopes.com/pisces/horoscope/today/')
    horoscope['Pisces'] = driver.find_element_by_xpath("/html/body/div[3]/div[1]/div[1]/main/div/p").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.nydailynews.com
print("------www.nydailynews.com------")
horoscope = {}
horoscope['Url'] = 'www.nydailynews.com'
#Aries
try:
    driver.get('http://www.nydailynews.com/horoscopes/aries')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Aries'] = temp.strip()
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('http://www.nydailynews.com/horoscopes/taurus')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Taurus'] = temp.strip()
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('http://www.nydailynews.com/horoscopes/gemini')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Gemini'] = temp.strip()
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('http://www.nydailynews.com/horoscopes/cancer')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Cancer'] = temp.strip()
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('http://www.nydailynews.com/horoscopes/leo')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Leo'] = temp.strip()
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('http://www.nydailynews.com/horoscopes/virgo')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Virgo'] = temp.strip()
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('http://www.nydailynews.com/horoscopes/libra')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Libra'] = temp.strip()
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('http://www.nydailynews.com/horoscopes/scorpio')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Scorpio'] = temp.strip()
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('http://www.nydailynews.com/horoscopes/sagittarius')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Sagittarius'] = temp.strip()
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('http://www.nydailynews.com/horoscopes/capricorn')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Capricorn'] = temp.strip()
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('http://www.nydailynews.com/horoscopes/aquarius')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Aquarius'] = temp.strip()
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('http://www.nydailynews.com/horoscopes/pisces')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    temp = page_check.find('div',{"class":"rt-b"}).p.text
    horoscope['Pisces'] = temp.strip()
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.chron.com
print("------www.chron.com------")
horoscope = {}
horoscope['Url'] = 'www.chron.com'
#using iframe url inside chron.com
driver.get('https://www.creators.com/widget/9296/horoscopes-by-holiday')

#Aries
try:
    horoscope['Aries'] = driver.find_element_by_xpath("/html/body/p[2]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    horoscope['Taurus'] = driver.find_element_by_xpath("/html/body/p[3]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    horoscope['Gemini'] = driver.find_element_by_xpath("/html/body/p[4]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    horoscope['Cancer'] = driver.find_element_by_xpath("/html/body/p[5]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    horoscope['Leo'] = driver.find_element_by_xpath("/html/body/p[6]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    horoscope['Virgo'] = driver.find_element_by_xpath("/html/body/p[7]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    horoscope['Libra'] = driver.find_element_by_xpath("/html/body/p[8]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    horoscope['Scorpio'] = driver.find_element_by_xpath("/html/body/p[9]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    horoscope['Sagittarius'] = driver.find_element_by_xpath("/html/body/p[10]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    horoscope['Capricorn'] = driver.find_element_by_xpath("/html/body/p[11]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    horoscope['Aquarius'] = driver.find_element_by_xpath("/html/body/p[12]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    horoscope['Pisces'] = driver.find_element_by_xpath("/html/body/p[13]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.sfgate.com
print("------www.sfgate.com------")
horoscope = {}
horoscope['Url'] = 'www.sfgate.com'
driver.get('https://www.sfgate.com/horoscope/')
temp_url = driver.find_element_by_xpath("/html/body/section/div[2]/div/div/div[2]/div[1]/div[1]/div/ul/li[1]/h3/a").get_attribute('href')
driver.get(temp_url)
#Aries
try:
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[1]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[2]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[3]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[4]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[5]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[6]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[7]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[8]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[9]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[10]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[11]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='content']/div[1]/div[2]/div[4]/p[12]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)


##www.theglobeandmail.com
print("------www.theglobeandmail.com------")
horoscope = {}
horoscope['Url'] = 'www.theglobeandmail.com'
driver.get('https://www.theglobeandmail.com/life/horoscopes/')
temp_url = driver.find_element_by_xpath("//*[@id='fbQ2N42a3w3cOq']/div[1]/div[1]/div/a").get_attribute('href')
driver.get(temp_url)
#Aries
try:
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[2]/font").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[3]/font").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[4]/font").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[5]/font").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[6]/font").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[7]/font").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[8]/font").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[9]/font").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[10]/font").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[11]/font").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[12]/font").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='fYZcep1HnVYmSq']/div/p[13]/font").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.thestar.com
print("------www.thestar.com------")
horoscope = {}
horoscope['Url'] = 'www.thestar.com'
driver.get('https://www.thestar.com/diversions/horoscope.html')
temp_url = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/div[1]/div/section/div[3]/div/div[1]/div/div/ul/li[2]/ul/li[1]/div/div[2]/span/span/a").get_attribute('href')
driver.get(temp_url)
#Aries
try:
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[5]/p[1]").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[5]/p[3]").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[7]/p[2]").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[7]/p[4]").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[9]/p[1]").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[11]/p[1]").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[11]/p[3]").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[11]/p[5]").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[11]/p[7]").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[11]/p[9]").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[11]/p[11]").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='app']/div/div[5]/div[2]/article/div[2]/div[2]/div/div/div/div[11]/p[13]").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)





##############################
### in this part js active
##############################
#init driver for mac
chromedriver = "/usr/local/bin/chromedriver"
os.environ["webdriver.chrome.driver"] = chromedriver
options = webdriver.ChromeOptions()
prefs = {"profile.managed_default_content_settings.images":2,'profile.managed_default_content_settings.javascript': 1,"profile.default_content_setting_values.notifications" : 2}
chrome_options.add_experimental_option("prefs",prefs)
chrome_options.add_argument("--disable-popup-blocking")
driver = webdriver.Chrome(executable_path=chromedriver, chrome_options=options)
driver.set_window_position(-10000,0)

###init driver for windows
##chrome_options = webdriver.ChromeOptions()
##prefs = {"profile.managed_default_content_settings.images":2,'profile.managed_default_content_settings.javascript': 1,"profile.default_content_setting_values.notifications" : 2}
##chrome_options.add_experimental_option("prefs",prefs)
##chrome_options.add_argument("--disable-popup-blocking")
##driver = webdriver.Chrome(chrome_options=chrome_options)
###driver.set_window_position(-10000,0)

##www.astrostyle.com
print("------www.astrostyle.com------")
horoscope = {}
horoscope['Url'] = 'www.astrostyle.com'
#Aries
try:
    driver.get('http://astrostyle.com/daily-horoscopes/aries-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Aries'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('http://astrostyle.com/daily-horoscopes/taurus-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Taurus'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('http://astrostyle.com/daily-horoscopes/gemini-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Gemini'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('http://astrostyle.com/daily-horoscopes/cancer-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Cancer'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('http://astrostyle.com/daily-horoscopes/leo-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Leo'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('http://astrostyle.com/daily-horoscopes/virgo-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Virgo'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('http://astrostyle.com/daily-horoscopes/libra-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Libra'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('http://astrostyle.com/daily-horoscopes/scorpio-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Scorpio'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('http://astrostyle.com/daily-horoscopes/sagittarius-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Sagittarius'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('http://astrostyle.com/daily-horoscopes/capricorn-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Capricorn'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('http://astrostyle.com/daily-horoscopes/aquarius-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Aquarius'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('http://astrostyle.com/daily-horoscopes/pisces-daily-horoscope/')
    html_check = driver.page_source
    page_check = soup(html_check,"html.parser")
    horoscope['Pisces'] = page_check.find('div',{"class":"weekday_div"}).p.text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)



##www.deccanherald.com
print("------www.deccanherald.com------")
horoscope = {}
horoscope['Url'] = 'www.deccanherald.com'
#Aries
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=aries')
    horoscope['Aries'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Aries: ",horoscope['Aries'],'\n\n')
except:
    horoscope['Aries']=''
    
#Taurus
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=taurus')
    horoscope['Taurus'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Taurus: ",horoscope['Taurus'],'\n\n')
except:
    horoscope['Taurus'] = ''
    
#Gemini
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=gemini')
    horoscope['Gemini'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Gemini: ",horoscope['Gemini'],'\n\n')
except:
    horoscope['Gemini'] = ''
    
#Cancer
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=cancer')
    horoscope['Cancer'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Cancer: ",horoscope['Cancer'],'\n\n')
except:
    horoscope['Cancer'] = ''
    
#Leo
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=leo')
    horoscope['Leo'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Leo: ",horoscope['Leo'],'\n\n')
except:
    horoscope['Leo'] = ''
    
#Virgo
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=virgo')
    horoscope['Virgo'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Virgo: ",horoscope['Virgo'],'\n\n')
except:
    horoscope['Virgo'] = ''
    
#Libra
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=libra')
    horoscope['Libra'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Libra: ",horoscope['Libra'],'\n\n')
except:
    horoscope['Libra'] = ''
    
#Scorpio
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=scorpio')
    horoscope['Scorpio'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Scorpio: ",horoscope['Scorpio'],'\n\n')
except:
    horoscope['Scorpio'] = ''

#Sagittarius
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=sagittarius')
    horoscope['Sagittarius'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Sagittarius: ",horoscope['Sagittarius'],'\n\n')
except:
    horoscope['Sagittarius'] = ''

#Capricorn
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=capricorn')
    horoscope['Capricorn'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Capricorn: ",horoscope['Capricorn'],'\n\n')
except:
    horoscope['Capricorn'] = ''

#Aquarius
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=aquarius')
    horoscope['Aquarius'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Aquarius: ",horoscope['Aquarius'],'\n\n')
except:
    horoscope['Aquarius'] = ''

#Pisces
try:
    driver.get('https://www.deccanherald.com/horoscope-detail?sign=pisces')
    horoscope['Pisces'] = driver.find_element_by_xpath("//*[@id='daily']/p").text
    print("Pisces: ",horoscope['Pisces'],'\n\n')
except:
    horoscope['Pisces'] = ''
    
#add to list
horo_list.append(horoscope)




#write to the file
with open('horoscope.csv', 'w', newline='') as csvfile:
    fieldnames = ['website','Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    time.sleep(1)
    for row in horo_list:
        writer.writerow({'website':row['Url'],'Aries':row['Aries'],'Taurus':row['Taurus'],'Gemini':row['Gemini'],'Cancer':row['Cancer'],'Leo':row['Leo'],'Virgo':row['Virgo'],'Libra':row['Libra'],'Scorpio':row['Scorpio'],'Sagittarius':row['Sagittarius'],'Capricorn':row['Capricorn'],'Aquarius':row['Aquarius'],'Pisces':row['Pisces']})


print("-------DONE-------")






